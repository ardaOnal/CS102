import java.awt.*;

/**
 *  
 * @author 
 * @version 
 */ 
public class MyPanel extends Panel
{
   // properties

   // constructors
   public MyPanel()
   {
      Button b;
      // setPreferredSize( new Dimension( 100, 100) );
      setSize( 200, 200);
      setLayout( new GridLayout( 2, 3) );
      
      add( new Label( "Welcome to ZOOM") );
      
      b = new Button( "OK");
      add( b);
      add( new Button( "Good luck with Maths! ") );
      
      add( new TextField( 25) );      
   }

   // methods
     
}