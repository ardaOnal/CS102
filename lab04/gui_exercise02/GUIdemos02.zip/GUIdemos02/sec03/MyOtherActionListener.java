   import java.awt.event.*;

    // nornal class
   class MyOtherActionListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         System.out.println( "Button pressed! ~ AL-other" );
      }      
   }